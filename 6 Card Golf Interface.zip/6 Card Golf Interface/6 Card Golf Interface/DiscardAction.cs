﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _6_Card_Golf_Interface
{
    internal class DiscardAction : GameAction
    {
        private DiscardPile discardPile;

        public DiscardAction(Player player, Deck deck, DiscardPile discardPile) : base(player, deck)
        {
            this.discardPile = discardPile;
        }

        public override void Execute()
        {
            Console.WriteLine($"{player.GetName()}'s cards:");
            player.ShowCards();
            string card = discardPile.TakeTopCard();
            if (card == null)
            {
                Console.WriteLine("The discard pile is empty.");
                return;
            }
            Console.WriteLine($"You took {card} from the discard pile.");
            Console.Write("Enter the position of the card to replace (1-6): ");
            int position = Convert.ToInt32(Console.ReadLine()) - 1;
            string replacedCard = player.ReplaceCard(position, card);
            if (replacedCard != null)
            {
                discardPile.Addcard(replacedCard);
                Console.WriteLine($"Replaced {replacedCard} with {card}");
            }
            else
            {
                discardPile.Addcard(card);
                Console.WriteLine("Invalid position.");
            }
            Console.WriteLine();
            Console.WriteLine("After the move:");
            player.ShowCards();
            Console.WriteLine();
            discardPile.ShowPile();
        }
    }
}
