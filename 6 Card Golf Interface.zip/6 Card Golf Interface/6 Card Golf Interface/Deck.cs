﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _6_Card_Golf_Interface
{
    internal class Deck
    {
        public List<string> CardDeck = new List<string>
            {"A♣", "2♣", "3♣", "4♣", "5♣", "6♣", "7♣", "8♣", "9♣", "10♣", "J♣", "Q♣", "K♣",
            "A♥", "2♥", "3♥", "4♥", "5♥", "6♥", "7♥", "8♥", "9♥", "10♥", "J♥", "Q♥", "K♥",
            "A♦", "2♦", "3♦", "4♦", "5♦", "6♦", "7♦", "8♦", "9♦", "10♦", "J♦", "Q♦", "K♦",
            "A♠", "2♠", "3♠", "4♠", "5♠", "6♠", "7♠", "8♠", "9♠", "10♠", "J♠", "Q♠", "K♠",
            "*", "*"};
        public List<string> BackUpDeck = new List<string>();
        public Dictionary<string, int> Points = new Dictionary<string, int> {
            {"A♣", 1}, {"A♥", 1}, {"A♦", 1}, {"A♠", 1},
            {"2♣", 2}, {"2♥", 2}, {"2♦", 2}, {"2♠", 2},
            {"3♣", 3}, {"3♥", 3}, {"3♦", 3}, {"3♠", 3},
            {"4♣", 4}, {"4♥", 4}, {"4♦", 4}, {"4♠", 4},
            {"5♣", 5}, {"5♥", 5}, {"5♦", 5}, {"5♠", 5},
            {"6♣", 6}, {"6♥", 6}, {"6♦", 6}, {"6♠", 6},
            {"7♣", 7}, {"7♥", 7}, {"7♦", 7}, {"7♠", 7},
            {"8♣", 8}, {"8♥", 8}, {"8♦", 8}, {"8♠", 8},
            {"9♣", 9}, {"9♥", 9}, {"9♦", 9}, {"9♠", 9},
            {"10♣", 10}, {"10♥", 10}, {"10♦", 10}, {"10♠", 10},
            {"J♣", 10}, {"J♥", 10}, {"J♦", 10}, {"J♠", 10},
            {"Q♣", 10}, {"Q♥", 10}, {"Q♦", 10}, {"Q♠", 10},
            {"K♣", 0}, {"K♥", 0}, {"K♦", 0}, {"K♠", 0},
            {"*", -2}};

        public void Shuffling()
        {
            CardDeck.Shuffle();
        }

        public string DrawCard()
        {
            if (CardDeck.Count == 0)
            {
                return null;
            }
            string card = CardDeck[0];
            CardDeck.RemoveAt(0);
            return card;
        }
    }

    class DiscardPile
    {
        private List<string> Cards = new List<string>();

        public void Addcard(string card)
        {
            Cards.Add(card);
        }

        public string TakeTopCard()
        {
            if (Cards.Count == 0)
            {
                return null;
            }
            string card = Cards[Cards.Count - 1];
            Cards.RemoveAt(Cards.Count - 1);
            return card;
        }

        public string GetTopCard()
        {
            if (Cards.Count == 0)
            {
                return null;
            }
            return Cards[Cards.Count - 1];
        }

        public void ShowPile()
        {
            Console.WriteLine("Discard Pile:");
            foreach (string card in Cards)
            {
                Console.WriteLine(card);
            }
        }
    }
}
