﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _6_Card_Golf_Interface
{
    public partial class Help : Form
    {
        public Help()
        {
            InitializeComponent();
        }
    }
}
