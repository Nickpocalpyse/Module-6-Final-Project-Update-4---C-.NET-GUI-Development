﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _6_Card_Golf_Interface
{
    internal class Player
    {
        private List<string> Cards;
        private List<bool> FaceUp;
        private string PlayerName;

        public Player(string PlayerName)
        {
            this.PlayerName = PlayerName;
            Cards = new List<string>();
            FaceUp = new List<bool>();
        }

        public string GetName()
        {
            return PlayerName;
        }

        public void AddCard(string card)
        {
            Cards.Add(card);
            FaceUp.Add(false);
        }

        public void ShowCards()
        {
            for (int i = 0; i < Cards.Count; i++)
            {
                if (FaceUp[i])
                {
                    Console.WriteLine($"{i + 1}: {Cards[i]}");
                }
                else
                {
                    Console.WriteLine($"{i + 1}: [Hidden]");
                }
            }
        }

        public string RemoveCard(int position)
        {
            if (position < 0 || position >= Cards.Count)
            {
                return null;
            }
            string card = Cards[position];
            Cards.RemoveAt(position);
            FaceUp.RemoveAt(position);
            return card;
        }

        public string ReplaceCard(int position, string ReplacementCard)
        {
            if (position < 0 || position >= Cards.Count)
            {
                return null;
            }
            string ReplacedCard = Cards[position];
            Cards[position] = ReplacementCard;
            FaceUp[position] = true;
            return ReplacedCard;
        }

        public void FirstTurn(int position)
        {
            if (position >= 0 && position < Cards.Count)
            {
                FaceUp[position] = true;
            }
        }

        public int CalculateScore(Dictionary<string, int> Points)
        {
            int score = 0;
            int[] PointsArray = new int[6];
            foreach (string card in Cards)
            {
                PointsArray[Cards.IndexOf(card)] = Points[card];
            }
            for (int i = 0; i < 3; i++)
            {
                if (PointsArray[i] == PointsArray[i + 3])
                {
                    score += PointsArray[i];
                }
                else
                {
                    score += PointsArray[i] + PointsArray[i + 3];
                }
            }
            return score;
        }
    }
}
