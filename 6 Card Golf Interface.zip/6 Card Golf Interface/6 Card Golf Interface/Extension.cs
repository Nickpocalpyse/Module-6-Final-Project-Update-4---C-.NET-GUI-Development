﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _6_Card_Golf_Interface
{
    internal static class Extension
    {
        private static Random rng = new Random();

        public static void Shuffle<T>(this IList<T> List)
        {
            int counter = List.Count;
            while (counter > 1)
            {
                counter--;
                int replacement = rng.Next(counter + 1);
                T value = List[replacement];
                List[replacement] = List[counter];
                List[counter] = value;
            }
        }
    }
}
