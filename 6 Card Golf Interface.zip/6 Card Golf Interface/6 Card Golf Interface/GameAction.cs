﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _6_Card_Golf_Interface
{
    internal class GameAction
    {
        protected Player player;
        protected Deck deck;

        public GameAction(Player player, Deck deck)
        {
            this.player = player;
            this.deck = deck;

        }
        public virtual void Execute()
        {
        }
    }
}
