﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _6_Card_Golf_Interface
{
    internal class DrawAction : GameAction
    {
        private DiscardPile discardPile;

        public DrawAction(Player player, Deck deck, DiscardPile discardPile) : base(player, deck)
        {
            this.discardPile = discardPile;
        }

        public override void Execute()
        {
            string card = deck.DrawCard();

            if (card != null)
            {
                Console.WriteLine($"{player.GetName()} drew the card: {card}");
                Console.Write("Enter the position of the card to replace (1-6): ");
                int position = Convert.ToInt32(Console.ReadLine());
                position--;
                string replacedCard = player.ReplaceCard(position, card);
                if (replacedCard != null)
                {
                    discardPile.Addcard(replacedCard);
                    Console.WriteLine($"Replaced {replacedCard} with {card}");
                }
                else
                {
                    Console.WriteLine("Invalid position.");
                    deck.CardDeck.Insert(0, card);
                }
            }
            else
            {
                Console.WriteLine("The deck is empty.");
            }
        }
    }
}
