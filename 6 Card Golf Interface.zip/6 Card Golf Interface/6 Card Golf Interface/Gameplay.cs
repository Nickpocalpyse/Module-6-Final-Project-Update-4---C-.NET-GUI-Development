using System;
using System.Windows.Forms;

namespace _6_Card_Golf_Interface
{
    public partial class CardGolf : Form

    {
        Player player1;
        Player player2;
        Player currentPlayer;
        Deck deck;
        DiscardPile discardPile;
        // Event handler for for setting the players names, flipping first move, and
        // replacing/not replacing cards after pressing enter
        private void txtPrompts_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string name = txtPrompts.Text.Trim();
                if (name == "")
                {
                    MessageBox.Show("Please enter a value");
                    return;
                }
                if (player1 == null)
                {
                    player1 = new Player(name);
                    lblUser1.Text = $"Player 1: {player1.GetName()}";
                    lblPrompts.Text = "Enter Player 2's name:";
                }
                else if (player2 == null)
                {
                    player2 = new Player(name);
                    lblUser2.Text = $"Player 2: {player2.GetName()}";
                    currentPlayer = player1;
                    lblPrompts.Text = $"{currentPlayer.GetName()}'s turn. Choose 2 cards to flip." +
                        $" Insert the first card number from left to right:";
                }
                txtPrompts.Text = "";
                e.SuppressKeyPress = true;
            }
        }

        public CardGolf()
        {
            InitializeComponent();
            deck = new Deck();
            discardPile = new DiscardPile();
            lblUser1Score.Text = "Score: 0";
            lblUser2Score.Text = "Score: 0";
            
            SetCardBacks();
        }

        // Method to set all card images to the back of the card
        private void SetCardBacks()
        {
            imgUser1Card1.Image = Properties.Resources.CardBack;
            imgUser1Card2.Image = Properties.Resources.CardBack;
            imgUser1Card3.Image = Properties.Resources.CardBack;
            imgUser1Card4.Image = Properties.Resources.CardBack;
            imgUser1Card5.Image = Properties.Resources.CardBack;
            imgUser1Card6.Image = Properties.Resources.CardBack;
            imgUser2Card1.Image = Properties.Resources.CardBack;
            imgUser2Card2.Image = Properties.Resources.CardBack;
            imgUser2Card3.Image = Properties.Resources.CardBack;
            imgUser2Card4.Image = Properties.Resources.CardBack;
            imgUser2Card5.Image = Properties.Resources.CardBack;
            imgUser2Card6.Image = Properties.Resources.CardBack;
            imgDrawPile.Image = Properties.Resources.CardBack;

        }

        //Methods to show and hide the turn option buttons
        private void ShowTurnButtons()
        {
            btnDrawDeck.Visible = true;
            btnDrawDiscard.Visible = true;
        }

        private void HideTurnButtons()
        {
            btnDrawDeck.Visible = false;
            btnDrawDiscard.Visible = false;
        }
    }
}
