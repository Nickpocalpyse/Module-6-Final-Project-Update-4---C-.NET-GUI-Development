﻿namespace _6_Card_Golf_Interface
{
    partial class CardGolf
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        // Button for opening a seperate form for help instructions
        private void btnHelp_Click(object sender, EventArgs e)
        {
            Help helpform = new Help();

            helpform.ShowDialog();
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnDrawDiscard = new Button();
            txtPrompts = new TextBox();
            lblPrompts = new Label();
            btnDrawDeck = new Button();
            btnHelp = new Button();
            lblUser1 = new Label();
            lblUser2 = new Label();
            lblUser2Score = new Label();
            lblUser1Score = new Label();
            imgDrawPile = new PictureBox();
            imgDiscardPile = new PictureBox();
            imgUser1Card4 = new PictureBox();
            imgUser1Card5 = new PictureBox();
            imgUser1Card6 = new PictureBox();
            imgUser1Card1 = new PictureBox();
            imgUser1Card2 = new PictureBox();
            imgUser1Card3 = new PictureBox();
            imgUser2Card1 = new PictureBox();
            imgUser2Card2 = new PictureBox();
            imgUser2Card3 = new PictureBox();
            imgUser2Card4 = new PictureBox();
            imgUser2Card5 = new PictureBox();
            imgUser2Card6 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)imgDrawPile).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgDiscardPile).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card6).BeginInit();
            SuspendLayout();
            // 
            // btnDrawDiscard
            // 
            btnDrawDiscard.Location = new Point(514, 158);
            btnDrawDiscard.Name = "btnDrawDiscard";
            btnDrawDiscard.RightToLeft = RightToLeft.Yes;
            btnDrawDiscard.Size = new Size(91, 62);
            btnDrawDiscard.TabIndex = 0;
            btnDrawDiscard.Text = "Pickup Discard pile card";
            btnDrawDiscard.UseVisualStyleBackColor = true;
            // 
            // txtPrompts
            // 
            txtPrompts.Location = new Point(437, 349);
            txtPrompts.Name = "txtPrompts";
            txtPrompts.Size = new Size(105, 21);
            txtPrompts.TabIndex = 1;
            txtPrompts.TextAlign = HorizontalAlignment.Center;
            txtPrompts.KeyDown += txtPrompts_KeyDown;
            // 
            // lblPrompts
            // 
            lblPrompts.Location = new Point(371, 316);
            lblPrompts.Name = "lblPrompts";
            lblPrompts.Size = new Size(247, 30);
            lblPrompts.TabIndex = 2;
            lblPrompts.Text = "Enter Player 1's name:";
            lblPrompts.TextAlign = ContentAlignment.MiddleCenter;
            lblPrompts.UseCompatibleTextRendering = true;
            // 
            // btnDrawDeck
            // 
            btnDrawDeck.Location = new Point(514, 37);
            btnDrawDeck.Name = "btnDrawDeck";
            btnDrawDeck.RightToLeft = RightToLeft.Yes;
            btnDrawDeck.Size = new Size(91, 62);
            btnDrawDeck.TabIndex = 3;
            btnDrawDeck.Text = "Pickup Deck pile card";
            btnDrawDeck.UseVisualStyleBackColor = true;
            // 
            // btnHelp
            // 
            btnHelp.BackColor = Color.Crimson;
            btnHelp.Location = new Point(10, 159);
            btnHelp.Name = "btnHelp";
            btnHelp.RightToLeft = RightToLeft.Yes;
            btnHelp.Size = new Size(82, 61);
            btnHelp.TabIndex = 4;
            btnHelp.Text = "Help";
            btnHelp.UseVisualStyleBackColor = false;
            btnHelp.Click += btnHelp_Click;
            // 
            // lblUser1
            // 
            lblUser1.AutoSize = true;
            lblUser1.Location = new Point(10, 335);
            lblUser1.Name = "lblUser1";
            lblUser1.Size = new Size(104, 15);
            lblUser1.TabIndex = 5;
            lblUser1.Text = "User1 name here";
            // 
            // lblUser2
            // 
            lblUser2.AutoSize = true;
            lblUser2.Location = new Point(10, 24);
            lblUser2.Name = "lblUser2";
            lblUser2.Size = new Size(104, 15);
            lblUser2.TabIndex = 6;
            lblUser2.Text = "User2 name here";
            // 
            // lblUser2Score
            // 
            lblUser2Score.AutoSize = true;
            lblUser2Score.Location = new Point(10, 61);
            lblUser2Score.Name = "lblUser2Score";
            lblUser2Score.Size = new Size(103, 15);
            lblUser2Score.TabIndex = 7;
            lblUser2Score.Text = "User2 score here";
            // 
            // lblUser1Score
            // 
            lblUser1Score.AutoSize = true;
            lblUser1Score.Location = new Point(11, 374);
            lblUser1Score.Name = "lblUser1Score";
            lblUser1Score.Size = new Size(103, 15);
            lblUser1Score.TabIndex = 8;
            lblUser1Score.Text = "User1 score here";
            // 
            // imgDrawPile
            // 
            imgDrawPile.Location = new Point(437, 26);
            imgDrawPile.Name = "imgDrawPile";
            imgDrawPile.Size = new Size(47, 73);
            imgDrawPile.SizeMode = PictureBoxSizeMode.Zoom;
            imgDrawPile.TabIndex = 9;
            imgDrawPile.TabStop = false;
            // 
            // imgDiscardPile
            // 
            imgDiscardPile.Location = new Point(437, 147);
            imgDiscardPile.Name = "imgDiscardPile";
            imgDiscardPile.Size = new Size(47, 73);
            imgDiscardPile.SizeMode = PictureBoxSizeMode.Zoom;
            imgDiscardPile.TabIndex = 10;
            imgDiscardPile.TabStop = false;
            // 
            // imgUser1Card4
            // 
            imgUser1Card4.Location = new Point(170, 335);
            imgUser1Card4.Name = "imgUser1Card4";
            imgUser1Card4.Size = new Size(47, 73);
            imgUser1Card4.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser1Card4.TabIndex = 11;
            imgUser1Card4.TabStop = false;
            // 
            // imgUser1Card5
            // 
            imgUser1Card5.Location = new Point(243, 335);
            imgUser1Card5.Name = "imgUser1Card5";
            imgUser1Card5.Size = new Size(47, 73);
            imgUser1Card5.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser1Card5.TabIndex = 12;
            imgUser1Card5.TabStop = false;
            // 
            // imgUser1Card6
            // 
            imgUser1Card6.Location = new Point(318, 335);
            imgUser1Card6.Name = "imgUser1Card6";
            imgUser1Card6.Size = new Size(47, 73);
            imgUser1Card6.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser1Card6.TabIndex = 13;
            imgUser1Card6.TabStop = false;
            // 
            // imgUser1Card1
            // 
            imgUser1Card1.Location = new Point(170, 246);
            imgUser1Card1.Name = "imgUser1Card1";
            imgUser1Card1.Size = new Size(47, 73);
            imgUser1Card1.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser1Card1.TabIndex = 14;
            imgUser1Card1.TabStop = false;
            // 
            // imgUser1Card2
            // 
            imgUser1Card2.Location = new Point(243, 246);
            imgUser1Card2.Name = "imgUser1Card2";
            imgUser1Card2.Size = new Size(47, 73);
            imgUser1Card2.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser1Card2.TabIndex = 15;
            imgUser1Card2.TabStop = false;
            // 
            // imgUser1Card3
            // 
            imgUser1Card3.Location = new Point(318, 246);
            imgUser1Card3.Name = "imgUser1Card3";
            imgUser1Card3.Size = new Size(47, 73);
            imgUser1Card3.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser1Card3.TabIndex = 16;
            imgUser1Card3.TabStop = false;
            // 
            // imgUser2Card1
            // 
            imgUser2Card1.Location = new Point(170, 12);
            imgUser2Card1.Name = "imgUser2Card1";
            imgUser2Card1.Size = new Size(47, 73);
            imgUser2Card1.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser2Card1.TabIndex = 17;
            imgUser2Card1.TabStop = false;
            // 
            // imgUser2Card2
            // 
            imgUser2Card2.Location = new Point(243, 12);
            imgUser2Card2.Name = "imgUser2Card2";
            imgUser2Card2.Size = new Size(47, 73);
            imgUser2Card2.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser2Card2.TabIndex = 18;
            imgUser2Card2.TabStop = false;
            // 
            // imgUser2Card3
            // 
            imgUser2Card3.Location = new Point(318, 12);
            imgUser2Card3.Name = "imgUser2Card3";
            imgUser2Card3.Size = new Size(47, 73);
            imgUser2Card3.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser2Card3.TabIndex = 19;
            imgUser2Card3.TabStop = false;
            // 
            // imgUser2Card4
            // 
            imgUser2Card4.Location = new Point(170, 102);
            imgUser2Card4.Name = "imgUser2Card4";
            imgUser2Card4.Size = new Size(47, 73);
            imgUser2Card4.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser2Card4.TabIndex = 20;
            imgUser2Card4.TabStop = false;
            // 
            // imgUser2Card5
            // 
            imgUser2Card5.Location = new Point(243, 102);
            imgUser2Card5.Name = "imgUser2Card5";
            imgUser2Card5.Size = new Size(47, 73);
            imgUser2Card5.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser2Card5.TabIndex = 21;
            imgUser2Card5.TabStop = false;
            // 
            // imgUser2Card6
            // 
            imgUser2Card6.Location = new Point(318, 102);
            imgUser2Card6.Name = "imgUser2Card6";
            imgUser2Card6.Size = new Size(47, 73);
            imgUser2Card6.SizeMode = PictureBoxSizeMode.Zoom;
            imgUser2Card6.TabIndex = 22;
            imgUser2Card6.TabStop = false;
            // 
            // CardGolf
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkGreen;
            ClientSize = new Size(617, 420);
            Controls.Add(imgUser2Card6);
            Controls.Add(imgUser2Card5);
            Controls.Add(imgUser2Card4);
            Controls.Add(imgUser2Card3);
            Controls.Add(imgUser2Card2);
            Controls.Add(imgUser2Card1);
            Controls.Add(imgUser1Card3);
            Controls.Add(imgUser1Card2);
            Controls.Add(imgUser1Card1);
            Controls.Add(imgUser1Card6);
            Controls.Add(imgUser1Card5);
            Controls.Add(imgUser1Card4);
            Controls.Add(imgDiscardPile);
            Controls.Add(imgDrawPile);
            Controls.Add(lblUser1Score);
            Controls.Add(lblUser2Score);
            Controls.Add(lblUser2);
            Controls.Add(lblUser1);
            Controls.Add(btnHelp);
            Controls.Add(btnDrawDeck);
            Controls.Add(lblPrompts);
            Controls.Add(txtPrompts);
            Controls.Add(btnDrawDiscard);
            Name = "CardGolf";
            Text = "6 Card Golf";
            ((System.ComponentModel.ISupportInitialize)imgDrawPile).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgDiscardPile).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card4).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card5).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card6).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card1).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card2).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser1Card3).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card1).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card2).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card3).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card4).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card5).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgUser2Card6).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnDrawDiscard;
        private TextBox txtPrompts;
        private Label lblPrompts;
        private Button btnDrawDeck;
        private Button btnHelp;
        private Label lblUser1;
        private Label lblUser2;
        private Label lblUser2Score;
        private Label lblUser1Score;
        private PictureBox imgDrawPile;
        private PictureBox imgDiscardPile;
        private PictureBox imgUser1Card4;
        private PictureBox imgUser1Card5;
        private PictureBox imgUser1Card6;
        private PictureBox imgUser1Card1;
        private PictureBox imgUser1Card2;
        private PictureBox imgUser1Card3;
        private PictureBox imgUser2Card1;
        private PictureBox imgUser2Card2;
        private PictureBox imgUser2Card3;
        private PictureBox imgUser2Card4;
        private PictureBox imgUser2Card5;
        private PictureBox imgUser2Card6;
    }
}
